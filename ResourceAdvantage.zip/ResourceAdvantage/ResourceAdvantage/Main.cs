﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Resources;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Reflection;
using System.IO;

namespace ResourceAdvantage
{
    public partial class Main : Form
    {
        //private System.Resources.ResourceManager resourceManager = new System.Resources.ResourceManager("DK.POC.BT.PipelineComponents.Resource", Assembly.GetExecutingAssembly());
       // Icon theIcon = new Icon(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("MyNameSpace.Filename.ico"));

        public Main()
        {
            InitializeComponent();
            try
            {
                //--------Resource Reader --------------//
                var ResReader = new ResXResourceReader(@"Properties\Resources.resx");
                foreach (DictionaryEntry d in ResReader)
                {
                    Debug.WriteLine("Resources values Key {0} and Value {1}", d.Key, d.Value);
                }

                int i = ResReader.BasePath.Length;
                ResReader.Close();
            }
            catch(Exception ex)
            {
                EventLog.WriteEntry("ResourceAdvantage.csproj", ex.Message, EventLogEntryType.Error);
            }
        }

        private void Main_Load(object sender, EventArgs e)
        {
            var resources = new ResourceManager(typeof(ResourceAdvantage.Properties.Resources));
            this.Text = resources.GetString("MainTitle");
            this.Icon = (Icon)resources.GetObject("transfer");
            lblAbout.Text = string.Format(" Auther: {0} \n\r Contact: {1}", resources.GetString("Auther"), resources.GetString("AutherEmail"));

            //alternatively 
            this.Text = ResourceAdvantage.Properties.Resources.MainTitle;
            this.Icon = ResourceAdvantage.Properties.Resources.transfer;
            lblAbout.Text = string.Format(" Auther: {0} \n\r Contact: {1}", ResourceAdvantage.Properties.Resources.Auther, ResourceAdvantage.Properties.Resources.AutherEmail);

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            openFileDialog.Title = "Browse Resource Files";
            openFileDialog.RestoreDirectory = true;
            openFileDialog.Filter = "Resource files (*.resx)|*.resx";
            openFileDialog.CheckFileExists = true;
            openFileDialog.CheckPathExists = true;
            //openFileDialog.
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string fName = openFileDialog.FileName;
                //GetFromResources(fName);
                txtRead.Text = "";
                var ResReader = new ResXResourceReader(fName);
                foreach (DictionaryEntry d in ResReader)
                {
                   txtRead.Text += string.Format("Resources values Key {0} and Value {1}\n\r", d.Key, d.Value);
                }
                ResReader.Close();
            }
        }

        private void btnWrite_Click(object sender, EventArgs e)
        {
            saveFileDialog.Title = "Save Resource Files";
            saveFileDialog.Filter = "Resource files (*.resx)|*.resx";
            saveFileDialog.CheckFileExists = false;
            saveFileDialog.CheckPathExists = false;
            saveFileDialog.RestoreDirectory = true;
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                ResXResourceWriter rsxw = new ResXResourceWriter(saveFileDialog.FileName);
                rsxw.AddResource("Title", txtWrite.Text);
                rsxw.Close();
            }
        }

        internal string GetFromResources(string resourceName)
        {
            Assembly assem = this.GetType().Assembly;
            using (Stream stream = assem.GetManifestResourceStream(resourceName))
            {
                if (stream == null)
                    return null;

                using (var reader = new StreamReader(stream))
                {
                    return reader.ReadToEnd();
                }
            }
        }

        private void lbllknow_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process myProcess = new Process();
            var ResReader = new ResXResourceReader(@"Properties\Resources.resx");
            myProcess.StartInfo.FileName = @"notepad.exe";
            myProcess.EnableRaisingEvents = true;

            myProcess.Start();
            myProcess.WaitForInputIdle(1000);
            if (myProcess.Responding)
            {
               SendKeys.Send("Resource Advantage\n------------------------\n");
                foreach (DictionaryEntry d in ResReader)
                {
                    if (d.Key.ToString().Contains("Advantage"))
                    {
                        Application.DoEvents();
                        SendKeys.SendWait(d.Value.ToString());
                        SendKeys.SendWait(Environment.NewLine);
                    }
                }
            }
            else
                myProcess.Kill();
            
        }
    }
}




